<?php
	require 'config.php';
	
	$username = $_POST['username'];

	$stmt = "select * from tbl_form where username ='$username'";
$run =$connect->prepare($stmt);
$run->execute();
$fetch = array();
while($row=$run->fetch(PDO::FETCH_ASSOC)){
$fetch['tbl_form'] =$row;
}
echo json_encode($fetch);

?>
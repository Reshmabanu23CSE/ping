$(document).ready(function(){  
      $('#register').click(function(){  
           var collegename = $('#collegename').val();  
           
		   var username = $('#username').val();  
		              var password = $('#password').val();  

		     		   var rollno = $('#rollno').val(); 		   
					    
 
		     		   var city = $('#city').val(); 		   

		     

           if(collegename == '' || username == ''|| password ==''|| rollno ==''|| city =='')  
           {  
                $('#error_message').html("All Fields are required");  
           }  
           else  
           {  
                $('#error_message').html('');  
                $.ajax({  
                     url:"register.php",  
                     method:"POST",  
                     data:{collegename:collegename, username:username, password:password, rollno:rollno, city:city},  
                     success:function(data){  
                          $("form").trigger("reset");  
                          $('#success_message').fadeIn().html(data);  
                          setTimeout(function(){  
                               $('#success_message').fadeOut("Slow");  
                          }, 2000);  
                     }  
                });  
           }  
      });  
 });  
